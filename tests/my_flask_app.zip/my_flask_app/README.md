# My_flask_app

Project initialized with Python Project Bootstrapper API.

## Template Used
flask

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python src/main.py
```
